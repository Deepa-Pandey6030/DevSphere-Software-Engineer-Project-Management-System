package com.demo.demo1;

import java.time.LocalDate;
import java.util.List;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Past;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public class SoftwareEngineerCreateDTO {
    @NotBlank(message="First name is required")
    private String firstName;

    @NotBlank(message="Last Name is required")
    private String lastName;

    @NotBlank(message="Email is required")
    @Email(message="Enter a valid email")
    private String email;

    @NotBlank(message="Phone numer is required")
    @Pattern(
    regexp = "^[0-9]{10}$",
    message = "Phone number must contain exactly 10 digits")
    private String phoneNumber;
    
    @NotNull(message="Date of birth is required")
    @Past(message="Date of birth should be in the past.")
    private LocalDate dateOfBirth;

    @NotEmpty(message="Tech Stack is required")
    @Size(max = 100, message = "Tech stack cannot contain more than 100 items")
    private List<String> techstack;

   
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(LocalDate dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public List<String> getTechstack() {
        return techstack;
    }

    public void setTechstack(List<String> techstack) {
        this.techstack = techstack;
    }
   
}
